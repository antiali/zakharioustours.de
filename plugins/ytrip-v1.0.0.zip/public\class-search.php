<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
class YTrip_Search {
    public function __construct() {}
}
new YTrip_Search();
