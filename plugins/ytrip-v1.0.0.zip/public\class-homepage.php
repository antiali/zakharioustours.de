<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
class YTrip_Homepage {
    public function __construct() {}
}
new YTrip_Homepage();
