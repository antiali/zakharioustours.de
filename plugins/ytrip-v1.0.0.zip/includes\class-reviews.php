<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
class YTrip_Reviews {
    public function __construct() {}
}
new YTrip_Reviews();
