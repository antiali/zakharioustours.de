<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
class YTrip_Core {
    public function __construct() {}
}
new YTrip_Core();
