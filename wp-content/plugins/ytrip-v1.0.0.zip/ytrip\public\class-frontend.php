<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
class YTrip_Frontend {
    public function __construct() {}
}
new YTrip_Frontend();
