<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
// Helper functions
