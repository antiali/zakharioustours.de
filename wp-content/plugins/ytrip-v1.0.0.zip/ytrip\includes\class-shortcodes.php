<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
class YTrip_Shortcodes {
    public function __construct() {}
}
new YTrip_Shortcodes();
